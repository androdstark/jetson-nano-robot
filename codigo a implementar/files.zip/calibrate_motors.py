#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
calibrate_motors.py — ROS Melodic (Python 2.7)
Mide la velocidad real de cada rueda a distintos niveles de PWM
para determinar MAX_WHEEL_SPEED del firmware.

Uso:
  1. Lanzar solo el bridge (sin move_base):
       roslaunch esp32_bridge esp32_bridge.launch
  2. En otra terminal:
       rosrun esp32_bridge calibrate_motors.py

Resultado: imprime tabla PWM% → m/s para actualizar MAX_WHEEL_SPEED en el .ino
"""

from __future__ import print_function
import rospy
import json
import serial
import time
import sys

# Parámetros — ajustar antes de correr
PORT          = '/dev/ttyUSB0'
BAUD          = 115200
WHEEL_RADIUS  = 0.033   # m
TICKS_PER_REV = 20
WHEEL_BASE    = 0.20

# Porcentajes de PWM a probar (el firmware usa MAX_WHEEL_SPEED como escala)
# Para calibrar: enviar v=X, w=0 y medir la vel real
TEST_SPEEDS = [0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.50]
MEAS_DURATION = 3.0  # segundos por punto


def main():
    print("=" * 55)
    print(" CALIBRACIÓN DE MOTORES ESP32 ")
    print("=" * 55)
    print("Conectando a {} @ {}...".format(PORT, BAUD))

    try:
        ser = serial.Serial(PORT, BAUD, timeout=0.2)
    except serial.SerialException as e:
        print("ERROR: {}".format(e))
        sys.exit(1)

    time.sleep(2)  # esperar boot del ESP32
    ser.flushInput()

    meters_per_tick = (2.0 * 3.14159265 * WHEEL_RADIUS) / TICKS_PER_REV

    results = []
    print("\n{:>8} {:>12} {:>12} {:>12}".format(
          "CMD m/s", "VEL_L m/s", "VEL_R m/s", "PROMEDIO"))
    print("-" * 50)

    for cmd_v in TEST_SPEEDS:
        # Enviar comando
        cmd = json.dumps({"v": cmd_v, "w": 0.0}) + "\n"
        ser.write(cmd.encode())

        # Leer durante MEAS_DURATION segundos y promediar
        samples_l = []
        samples_r = []
        t_start = time.time()
        prev_tl = None
        prev_tr = None
        prev_t  = None

        while (time.time() - t_start) < MEAS_DURATION:
            line = ser.readline().decode('utf-8', errors='ignore').strip()
            if not line:
                continue
            try:
                d = json.loads(line)
            except ValueError:
                continue
            if 'ticks_l' not in d:
                continue

            now = time.time()
            if prev_tl is not None and prev_t is not None:
                dt = now - prev_t
                if dt > 0:
                    dl = (d['ticks_l'] - prev_tl) * meters_per_tick / dt
                    dr = (d['ticks_r'] - prev_tr) * meters_per_tick / dt
                    samples_l.append(dl)
                    samples_r.append(dr)
            prev_tl = d['ticks_l']
            prev_tr = d['ticks_r']
            prev_t  = now

        # Parar motores
        ser.write((json.dumps({"v": 0.0, "w": 0.0}) + "\n").encode())
        time.sleep(0.5)

        if samples_l:
            avg_l = sum(samples_l) / len(samples_l)
            avg_r = sum(samples_r) / len(samples_r)
            avg   = (avg_l + avg_r) / 2.0
            print("{:>8.2f} {:>12.4f} {:>12.4f} {:>12.4f}".format(
                  cmd_v, avg_l, avg_r, avg))
            results.append((cmd_v, avg_l, avg_r))
        else:
            print("{:>8.2f}  (sin datos — aumentar MEAS_DURATION?)".format(cmd_v))

    ser.close()

    # Calcular MAX_WHEEL_SPEED como vel promedio a cmd_v=TEST_SPEEDS[-1]
    if results:
        last = results[-1]
        max_v = (last[1] + last[2]) / 2.0
        print("\n" + "=" * 55)
        print("RESULTADO:")
        print("  A cmd_v={:.2f} m/s → vel_real={:.4f} m/s".format(last[0], max_v))
        print("\n  Actualizar en esp32_motor_control.ino:")
        print("  #define MAX_WHEEL_SPEED  {:.4f}f".format(max_v / last[0] * 0.50))
        print("\n  (La constante es la vel a PWM=255, no a cmd_v=0.5)")
        print("=" * 55)


if __name__ == '__main__':
    main()
