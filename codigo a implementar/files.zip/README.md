# Robot Diferencial — Jetson Nano + ESP32 + Orbbec Astra

Stack completo: ROS Melodic · Python 2.7 · Arduino ESP32 · JetPack 4.6.4

---

## Índice
1. [Estructura de archivos](#estructura)
2. [Hardware y cableado](#hardware)
3. [Instalación](#instalación)
4. [Configuración](#configuración)
5. [Uso](#uso)
6. [Calibración](#calibración)
7. [Troubleshooting](#troubleshooting)

---

## Estructura

```
robot/
├── firmware/
│   └── esp32_motor_control.ino       # Firmware ESP32
├── ros/src/
│   ├── esp32_bridge/
│   │   ├── src/
│   │   │   ├── esp32_bridge.py       # Nodo ROS bridge Serial↔ROS
│   │   │   └── calibrate_motors.py  # Utilidad de calibración
│   │   └── launch/
│   │       └── esp32_bridge.launch
│   └── robot_nav/
│       ├── urdf/robot.urdf.xacro     # Descripción 3D del robot
│       ├── config/
│       │   ├── gmapping.yaml
│       │   ├── costmap_common.yaml
│       │   ├── local_costmap.yaml
│       │   ├── global_costmap.yaml
│       │   └── base_local_planner_params.yaml
│       └── launch/
│           ├── navigation.launch     # ← punto de entrada principal
│           ├── depth_to_laserscan.launch
│           └── robot_description.launch
├── dashboard/
│   └── robot_dashboard.html          # Dashboard web (rosbridge)
└── install_deps.sh                   # Script de instalación
```

---

## Hardware y cableado

### Componentes
| Componente | Notas |
|---|---|
| Jetson Nano 4GB (JetPack 4.6.4) | Computadora principal |
| ESP32 DevKit (any 38-pin) | Control de motores |
| L298N | Driver de motores |
| 2× Motor DC con eje | Con imanes para encoder |
| 2× KY-003 (Hall effect) | Sensor de velocidad/odometría |
| Orbbec Astra Pro Plus | Cámara de profundidad 30Hz |
| Fuente 12V (motors) + 5V (lógica) | Separar alimentación |

---

### Diagrama de cableado ESP32 ↔ L298N ↔ Motores

```
                        ┌──────────────────────────┐
                        │          L298N            │
  ESP32                 │                          │
  ┌─────┐               │  ENA ←── GPIO25          │
  │ 25  │──────────────▶│  IN1 ←── GPIO26    OUT1 ─┼──── Motor Izq (+)
  │ 26  │──────────────▶│  IN2 ←── GPIO27    OUT2 ─┼──── Motor Izq (-)
  │ 27  │──────────────▶│                          │
  │ 14  │──────────────▶│  ENB ←── GPIO14    OUT3 ─┼──── Motor Der (+)
  │ 12  │──────────────▶│  IN3 ←── GPIO12    OUT4 ─┼──── Motor Der (-)
  │ 13  │──────────────▶│  IN4 ←── GPIO13          │
  └──┬──┘               │                          │
     │                  │  +12V ←── Batería 12V    │
    GND ────────────────┤  GND  ←── GND común      │
                        │  +5V  ──▶ ESP32 VIN (opt)│
                        └──────────────────────────┘

  Encoders KY-003:

  ESP32              KY-003 Izq          KY-003 Der
  ┌─────┐            ┌─────────┐         ┌─────────┐
  │ 34  │◀── S ──────│ S  VCC  │         │ S  VCC  │
  │ 3V3 │──── VCC ──▶│         │         │         │──── GPIO35
  │ GND │──── GND ──▶│ GND     │         │ GND     │
  └─────┘            └─────────┘         └─────────┘
                         ↑                   ↑
                     [imanes en          [imanes en
                      eje rueda izq]      eje rueda der]

  NOTA: GPIO34 y GPIO35 son input-only en ESP32.
        Si el KY-003 es open-collector, añadir pull-up
        externo de 10kΩ a 3.3V en la línea de señal.

  Jetson Nano ↔ ESP32:

  Jetson Nano USB ──── USB-micro/C del ESP32
  (aparece como /dev/ttyUSB0 o /dev/esp32 con udev rule)
```

---

### Distribución de imanes KY-003
```
  Vista frontal del eje de rueda:

       N   S         Recomendado: 4 imanes = 4 pulsos/rev
      ╱   ╲          (más = mejor resolución, menos = menos ruido)
     S     N         TICKS_PER_REV en firmware debe coincidir
      ╲   ╱          con el número de imanes montados.
       N   S

  Montar imanes alternando N-S alrededor del eje en un disco
  de plástico/madera. El KY-003 debe quedar a ~2-5mm del disco.
```

---

## Instalación

### 1. Firmware ESP32

```bash
# En Arduino IDE o VS Code + PlatformIO:
# 1. Instalar "ESP32 by Espressif" desde Board Manager
# 2. Instalar "ArduinoJson" v6.x desde Library Manager
# 3. Abrir firmware/esp32_motor_control.ino
# 4. Ajustar parámetros (ver sección Configuración)
# 5. Board: "ESP32 Dev Module", Upload Speed: 921600
# 6. Upload

# Verificar en Serial Monitor (115200 baud):
# Debe mostrar JSON cada 50ms: {"lv":0.0,"rv":0.0,"ticks_l":0,"ticks_r":0}
```

### 2. Dependencias ROS en Jetson Nano

```bash
chmod +x install_deps.sh
./install_deps.sh
```

### 3. Workspace catkin

```bash
mkdir -p ~/catkin_ws/src
cp -r ros/src/* ~/catkin_ws/src/
cd ~/catkin_ws
catkin_make -DCMAKE_BUILD_TYPE=Release
source devel/setup.bash

# Añadir a ~/.bashrc para que persista:
echo "source ~/catkin_ws/devel/setup.bash" >> ~/.bashrc
```

### 4. Permisos Serial

```bash
# Con udev rule instalada (install_deps.sh la instala):
ls -la /dev/esp32    # debe existir

# Sin udev rule:
sudo chmod 666 /dev/ttyUSB0
# O permanente:
sudo usermod -aG dialout $USER   # requiere logout
```

---

## Configuración

### Parámetros del firmware (`esp32_motor_control.ino`)

```cpp
// Editar estas líneas según tu hardware:
#define WHEEL_BASE      0.20f   // metros entre centros de ruedas
#define WHEEL_RADIUS    0.033f  // metros (radio de rueda)
#define TICKS_PER_REV   20      // número de imanes por rueda

#define MAX_WHEEL_SPEED 0.5f    // m/s a PWM=255 — CALIBRAR (ver abajo)
```

### Parámetros del URDF (`robot_nav/urdf/robot.urdf.xacro`)

```xml
<!-- Posición física de la cámara respecto al centro del robot -->
<xacro:property name="cam_x"     value="0.10"/>   <!-- m adelante -->
<xacro:property name="cam_z"     value="0.20"/>   <!-- m arriba -->
<xacro:property name="cam_pitch" value="0.1745"/> <!-- rad hacia abajo (~10°) -->
```

### Parámetros del bridge (`esp32_bridge.launch`)

```xml
<param name="port"          value="/dev/ttyUSB0"/>  <!-- o /dev/esp32 -->
<param name="wheel_base"    value="0.20"/>
<param name="wheel_radius"  value="0.033"/>
<param name="ticks_per_rev" value="20"/>
<param name="cmd_timeout"   value="0.5"/>  <!-- s sin cmd → parar -->
```

---

## Uso

### Lanzar stack completo

```bash
# Stack completo (SLAM + navegación + cámara + dashboard)
roslaunch robot_nav navigation.launch

# Solo el bridge (desarrollo/calibración)
roslaunch esp32_bridge esp32_bridge.launch

# Con parámetros personalizados:
roslaunch robot_nav navigation.launch serial_port:=/dev/ttyUSB1 wheel_base:=0.22
```

### Dashboard web

1. Abrir `dashboard/robot_dashboard.html` en un navegador (Chrome/Firefox)
2. Verificar que apunta a `ws://<IP_JETSON>:9090`
3. Hacer click en la URL del header para cambiarla si es necesario

```bash
# Obtener IP del Jetson:
hostname -I
```

### Control manual por teclado (RViz o dashboard)

| Tecla | Acción |
|---|---|
| W / ↑ | Avanzar |
| S / ↓ | Retroceder |
| A / ← | Girar izquierda |
| D / → | Girar derecha |
| Espacio | Stop |

### Navegación autónoma (AMCL + move_base)

```bash
# Una vez construido el mapa con gmapping:
# 1. Guardar mapa:
rosrun map_server map_saver -f ~/maps/mapa_sala

# 2. Para reutilizar el mapa guardado (localización, no SLAM):
# Reemplazar slam_gmapping por amcl + map_server en navigation.launch
rosrun map_server map_server ~/maps/mapa_sala.yaml &

# 3. Enviar goal desde RViz o desde código:
rostopic pub /move_base_simple/goal geometry_msgs/PoseStamped \
  '{ header: {frame_id: "map"}, pose: { position: {x: 1.0, y: 0.5}, orientation: {w: 1.0}}}'
```

---

## Calibración

### MAX_WHEEL_SPEED (más importante)

```bash
# Con el ESP32 conectado y SIN lanzar el bridge:
python ros/src/esp32_bridge/src/calibrate_motors.py

# El script mide vel real a distintos PWM y sugiere el valor correcto.
# Actualizar #define MAX_WHEEL_SPEED en el .ino y re-flashear.
```

### TICKS_PER_REV

```bash
# Contar imanes físicamente en cada rueda.
# Marcar un punto en la rueda, girarla 1 vuelta completa a mano
# y verificar en Serial Monitor cuántos pulsos llegan.
```

### Odometría — verificar drift

```bash
# Mover robot 1 metro exacto hacia adelante y medir pose reportada:
rostopic echo /odom | grep position

# Si drift > 10%: ajustar wheel_radius (el parámetro más sensible)
# Si gira sin querer: ajustar wheel_base
```

---

## Troubleshooting

### `/scan` no se publica
```
# Verificar que depthimage_to_laserscan está corriendo:
rosnode list | grep depth
# Verificar que la cámara publica:
rostopic hz /camera/depth/image_raw   # debe ser ~30 Hz
# Verificar TF entre camera_depth_frame y base_link:
rosrun tf tf_echo base_link camera_depth_frame
```

### ESP32 no responde
```
# Verificar puerto:
ls /dev/ttyUSB* /dev/ttyACM*
# Probar comunicación directa:
screen /dev/ttyUSB0 115200
# Enviar: {"v":0.1,"w":0.0}  → debe recibir JSON de odometría
# Salir screen: Ctrl+A, luego K
```

### gmapping diverge / mapa incorrecto
```
# Síntomas: partículas se dispersan, mapa se deforma
# Causas comunes:
#   1. TF de cámara a base_link mal configurada → ajustar URDF
#   2. Velocidad demasiado alta → reducir max_vel_x en DWA params
#   3. Scan sintético muy ruidoso → aumentar scan_height en depth_to_laserscan
#   4. Odometría con drift → recalibrar MAX_WHEEL_SPEED y TICKS_PER_REV
```

### move_base no encuentra ruta
```
# 1. Verificar footprint vs inflation_radius (robot debe caber en pasillos)
# 2. Verificar que /map se publica: rostopic hz /map
# 3. Reducir inflation_radius de 0.25 a 0.20 si los pasillos son muy estrechos
# 4. Aumentar planner_patience en navigation.launch
```

### Dashboard no conecta
```
# 1. Verificar rosbridge corriendo: rosnode list | grep rosbridge
# 2. Verificar puerto: netstat -tlnp | grep 9090
# 3. Verificar firewall: sudo ufw allow 9090
# 4. En Jetson: la IP del modo USB gadget es 192.168.55.1
#    En red WiFi usar: hostname -I
```

---

## Notas de arquitectura

- **Dirección de encoder**: Los KY-003 cuentan pulsos sin sentido de dirección.
  El firmware infiere el signo desde `target_v`. Esto significa que si hay
  deslizamiento mientras el motor frena, los ticks pueden contar en sentido
  erróneo. Para mayor precisión añadir encoders en cuadratura (dos sensores
  Hall desfasados 90°) o encoders ópticos con canal A/B.

- **Frame de profundidad**: El driver oficial de Orbbec publica el frame como
  `camera_depth_optical_frame`. Si `depthimage_to_laserscan` da error de TF,
  cambiar `output_frame_id` en el launch al frame real que publica el driver
  (`rosrun tf view_frames` para verlo todo).

- **Latencia Serial**: El bridge usa `Serial.setTimeout(10)` en el ESP32 y
  un hilo de lectura en Python. La latencia típica es 10-30ms, suficiente para
  20Hz de odometría. Si se observa lag, reducir `PUBLISH_INTERVAL_MS` a 40ms.
